import subprocess
import json
from openpyxl import Workbook

results = []

for num in range(1, 56):
    print(f"Running instance {num}...")
    proc = subprocess.run(
        ["python", "C:\\Users\\Solver.py", str(num)], # provide path to solver file
        capture_output=True,
        text=True
    )
    
    print(proc.stdout)   # <-- this shows all solver print() output

    lines = [line for line in proc.stdout.splitlines() if line.strip()]
    if not lines:
        print(f"Instance {num} produced no output")
        print("stderr was:\n", proc.stderr)  # <-- show solver errors
        # add placeholder row so Excel has 55 entries
        results.append({
            "Instance": num,
            "Objective": None,
            "x*": [],
            "y*": [],
            "Time": None,
            "Polyhedrons_explored": None,
            "Empty_hyperplanes": None,
            "Status": "no_output"
        })
        continue

    last_line = lines[-1]
    try:
        res = json.loads(last_line)
        results.append(res)
    except Exception as e:
        print(f"Instance {num} failed to parse JSON: {e}")
        print("Solver stdout was:\n", proc.stdout)
        print("Solver stderr was:\n", proc.stderr)
        # add placeholder row
        results.append({
            "Instance": num,
            "Objective": None,
            "x*": [],
            "y*": [],
            "Time": None,
            "Polyhedrons_explored": None,
            "Empty_hyperplanes": None,
            "Status": "parse_error"
        })

wb = Workbook()
ws = wb.active
ws.append(["Instance", "Objective", "x*", "y*", "Time", "Polyhedrons_explored", "Empty_hyperplanes", "Status"])

for res in results:
    ws.append([
        res.get("Instance"),
        res.get("Objective"),
        ",".join(map(str, res.get("x*", []))),
        ",".join(map(str, res.get("y*", []))),
        res.get("Time"),
        res.get("Polyhedrons_explored"),
        res.get("Empty_hyperplanes"),
        res.get("Status")
    ])

wb.save("BLP_results.xlsx")
print("Results written to BLP_results.xlsx")