import numpy as np
import time
import gurobipy as gp
from gurobipy import GRB
import json, sys
import os


start_time = time.perf_counter()

# Get instance number from command line
# -------------------------
if len(sys.argv) < 2:
    print("Usage: python PEA_Bimatrix_Timed_2mins.py <instance_number>")
    sys.exit(1)

num = int(sys.argv[1])  # instance number passed in

# -------------------------
# Load data using num
# -------------------------
base = fr"C:\\Users\\Bimatrix\\BM_m20n20Num{num}" #path to problems
Ax = np.loadtxt(base + "_A_y.txt", delimiter=",")
E  = np.loadtxt(base + "_A_x.txt", delimiter=",")
Q_bef = Ax + E
new_column = -1 * np.ones((E.shape[0], 1))  # column of -1s with same number of rows as Ax
E = np.hstack([E, new_column])
E = -E
x_LH  = np.loadtxt(base + "_x_LH.txt")
y_LH  = np.loadtxt(base + "_y_LH.txt")


# -------------------------
# Build Q, A, dimensions, c, d
# -------------------------
m = Ax.shape[0]
n = m + Ax.shape[1] + 1
p = E.shape[1]
l = E.shape[0]
b = np.zeros(m)
b = np.append(b, 1)
f = np.zeros(l)
f = -f
f = np.append(f, -1)

Q = np.zeros((n, p))      # full target matrix
Q[:m, :p-1] = Q_bef         # embed Q_bef in the top-left block
Q = -Q

Ax= Ax.T
new_column = -1 * np.ones((Ax.shape[0], 1))  # column of -1s with same number of rows as Ax
Ax = np.hstack([Ax, new_column])
A = np.hstack([Ax, np.eye(m)])
new_row = np.hstack([np.ones(n - m), np.zeros(m)])
A = np.vstack([A, new_row])
A[-1, m] = 0
row = -np.ones((1, p))     # start with -1s
row[0, p-1] = 0            # set the p-th element (index p-1) to 0
E = np.vstack([E, row])

c = np.zeros(n)
c[m] = -1
c = -c
d = np.zeros(p-1)
d = np.append(d, -1)
d = -d

E_Delta = np.zeros((l + 1, p + 1))
E_Delta[:, :p] = E
E_Delta[:, p] = -1.0

# -------------------------
# Model y (dual-like)
# -------------------------
modely = gp.Model("lp_y")
modely.setParam('OutputFlag', 0)
y = modely.addMVar(shape=p, vtype=GRB.CONTINUOUS, lb=0.0, ub=GRB.INFINITY, name="y")
y[p-1].LB = -GRB.INFINITY
modely.update()
np.random.seed(3)      # choose any integer seed
solx = -np.full(n, np.random.rand())
objy = solx.dot(Q) + d
modely.setMObjective(None, np.array(objy), 0.0, sense=GRB.MINIMIZE)
modely.addMConstr(E[:-1], None, GRB.GREATER_EQUAL, f[:-1])
modely.addMConstr(E[-1:], None, GRB.EQUAL, f[-1:])
modely.update()
modely.optimize()
soly = np.array(modely.getAttr('x'))

# -------------------------
# Model x (primal-like)
# -------------------------
modelx = gp.Model("lp_x")
modelx.setParam('OutputFlag', 0)
x = modelx.addMVar(shape=n, vtype=GRB.CONTINUOUS, lb=0.0, ub=GRB.INFINITY, name="x")
x[m].LB = -GRB.INFINITY
modelx.update()
objx = soly.dot(Q.T) + c
modelx.setMObjective(None, np.array(objx), 0.0, xQ_L=x, xQ_R=None, xc=None, sense=GRB.MINIMIZE)
modelx.addMConstr(A, x, GRB.EQUAL, b, name="Ax_eq_b")
modelx.optimize()
solx = modelx.getAttr('x')

# -------------------------
# Basis extraction
# -------------------------
vbasis = np.array(modelx.getAttr('Vbasis'))
basishead = list(np.where(vbasis == 0)[0])
nonbasis = list(np.where(vbasis != 0)[0])

B = A[:, basishead]
N = A[:, nonbasis]
BinvN = np.linalg.inv(B).dot(N)

QN = Q[nonbasis, :]
cN = c[nonbasis]
QB = Q[basishead, :]
cB = c[basishead]

G = QN - (BinvN.T.dot(QB))
h = (BinvN.T.dot(cB)) - cN

# -------------------------
# Set_L structure
# -------------------------
class Set_L_Struct:
    def __init__(self, ind=1, poly=0, LHS=None, RHS=0.0):
        self.ind = ind
        self.poly = poly
        self.LHS = np.array(LHS) if LHS is not None else np.zeros(p)
        self.RHS = float(RHS)

Set_L = []
for ii in range(G.shape[0]):
    LHS_row = G[ii]
    RHS_val = h[ii]
    ind_flag = 1 if not np.allclose(LHS_row, 0.0) else 0
    Set_L.append(Set_L_Struct(ind=ind_flag, poly=0, LHS=LHS_row, RHS=RHS_val))

s = 1e-6
basis_counter = 1
count_rel_interior_empty = 0

def Step_1():
    return 1 if all(item.ind == 0 for item in Set_L) else 0

def Step_4(yi_vec):
    if not np.all(E.dot(yi_vec) >= f - 1e-15):
        return 0
    L_len = len(Set_L)
    num_polys = L_len // (n - m) if (n - m) > 0 else 0
    for poly_idx in range(num_polys):
        start = poly_idx * (n - m)
        ok_all = True
        for j in range(start, start + (n - m)):
            item = Set_L[j]
            if round(item.LHS.dot(yi_vec) - item.RHS, 15) < 0:
                ok_all = False
                break
        if ok_all:
            return 1
    return 0

# -------------------------
# modeldummy for Step 2/3
# -------------------------
modeldummy = gp.Model("lp_dummy")
modeldummy.setParam('OutputFlag', 0)
Cvars = modeldummy.addVars(range(p), lb=-GRB.INFINITY, vtype=GRB.CONTINUOUS)
Delta = modeldummy.addVar(name="Delta")
modeldummy.update()
modeldummy.setObjective(Delta, GRB.MAXIMIZE)

# -------------------------
# Main loop
# -------------------------

# Initial incumbent objective
zbar = np.dot(objy,soly) + np.dot(c,solx)

# Store initial incumbent solutions
xbar = solx.copy()
ybar = soly.copy()

while True:
    L_empty = Step_1()
    if L_empty == 1:
        print("\n\n--- %.2f seconds ---" % (time.perf_counter() - start_time))
        print("xbar:", solx)
        print("ybar:", soly)
        print("Incumbent value of objective function:", zbar)
        print("No. of hyperplanes with no relative interior:", count_rel_interior_empty)
        print("No. of optimality polyhedrons explored is ",len(Set_L)/(n-m-1))
        output = {
            "Instance": int(sys.argv[1]),
            "Objective": float(zbar),
            "x*": list(solx),
            "y*": list(soly),
            "Time": time.perf_counter() - start_time,
            "Polyhedrons_explored": float(len(Set_L)/(n-m-1)),
            "Empty_hyperplanes": int(count_rel_interior_empty)
            }
        print(json.dumps(output), flush=True)
        os._exit(0)
        
    elif(zbar <= 1e-6):
        print("\n\n--- %.2f seconds ---" % (time.perf_counter() - start_time))
        print("xbar:", solx)
        print("ybar:", soly)
        print("Incumbent value of objective function:", zbar)
        print("No. of hyperplanes with no relative interior:", count_rel_interior_empty)
        print("No. of optimality polyhedrons explored is ",len(Set_L)/(n-m-1))
        output = {
            "Instance": int(sys.argv[1]),
            "Objective": float(zbar),
            "x*": list(solx),
            "y*": list(soly),
            "Time": time.perf_counter() - start_time,
            "Polyhedrons_explored": float(len(Set_L)/(n-m-1)),
            "Empty_hyperplanes": int(count_rel_interior_empty)
            }
        print(json.dumps(output), flush=True)
        os._exit(0)

    elif(time.perf_counter() - start_time >=200.00):
        print("\n\n--- %.2f seconds ---" % (time.perf_counter() - start_time))
        print("xbar:", solx)
        print("ybar:", soly)
        print("Incumbent value of objective function:", zbar)
        print("No. of hyperplanes with no relative interior:", count_rel_interior_empty)
        print("No. of optimality polyhedrons explored is ",len(Set_L)/(n-m-1))
        output = {
            "Instance": int(sys.argv[1]),
            "Objective": float(zbar),
            "x*": list(solx),
            "y*": list(soly),
            "Time": time.perf_counter() - start_time,
            "Polyhedrons_explored": float(len(Set_L)/(n-m-1)),
            "Empty_hyperplanes": int(count_rel_interior_empty)
            }
        print(json.dumps(output),flush=True)
        os._exit(0)

    # Find next active Set_L
    active_indices = [idx for idx, item in enumerate(Set_L) if item.ind != 0]
    if len(active_indices) == 0:
        print("No more active hyperplanes, terminating loop.")
        break

    q = active_indices[0]
    alpha = Set_L[q].LHS.copy()
    beta = Set_L[q].RHS
    k = Set_L[q].poly
    Set_L[q].ind = 0

    # Build Skq_delta_hat excluding q
    rows = []
    rhs_vals = []
    for ii in range(k * (n - m), (k + 1) * (n - m)):
        if ii == q: continue
        if ii < len(Set_L):
            lhs_row = Set_L[ii].LHS
            rhs_val = Set_L[ii].RHS
        else:
            lhs_row = np.zeros(p)
            rhs_val = 0.0
        rows.append(np.concatenate([lhs_row, [-1.0]]))
        rhs_vals.append(rhs_val)
    if len(rows) == 0:
        continue
    Skq_delta_hat = np.vstack(rows)
    Skq_delta_RHS = np.array(rhs_vals)

    # Reset dummy model
    for con in list(modeldummy.getConstrs()):
        modeldummy.remove(con)
    modeldummy.update()

    # Add Skq constraints
    modeldummy.addMConstr(Skq_delta_hat, None, GRB.GREATER_EQUAL, Skq_delta_RHS, "Skq")
    modeldummy.update()

    # Add alpha.Cvars == beta
    linexpr = gp.LinExpr()
    for kk in range(p):
        linexpr += alpha[kk] * Cvars[kk]
    modeldummy.addConstr(linexpr, GRB.EQUAL, beta, name='alpha')
    modeldummy.update()

    modeldummy.optimize()
    status = modeldummy.status

    # Handle dummy optimization
    if status == GRB.OPTIMAL and modeldummy.objVal > -1e-6:
        yi_hat_vals = np.array([Cvars[i].x for i in range(p)])
        magni = s / np.linalg.norm(alpha) if np.linalg.norm(alpha) > 0 else 0.0
        yi = yi_hat_vals - magni * alpha
        if Step_4(yi) == 1:
            continue
        # Update x model using yi
        objx = yi.dot(Q.T) + c
        modelx.reset(0)
        modelx.setMObjective(None, objx, 0.0, xQ_L=x, xQ_R=None, xc=None, sense=GRB.MINIMIZE)
        modelx.optimize()
        solx = modelx.getAttr('x')
        # recompute basis
        vbasis = np.array(modelx.getAttr('Vbasis'))
        basishead = list(np.where(vbasis == 0)[0])
        nonbasis = list(np.where(vbasis != 0)[0])
        B = A[:, basishead]
        N = A[:, nonbasis]
        BinvN = np.linalg.inv(B).dot(N)
        QN = Q[nonbasis, :]
        cN = c[nonbasis]
        QB = Q[basishead, :]
        cB = c[basishead]
        G = QN - (BinvN.T.dot(QB))
        h = (BinvN.T.dot(cB)) - cN
        objy = np.matmul(np.transpose(solx),Q) + np.transpose(d)
        modely.reset(0)
        modely.setMObjective(None, objy,0.0, xQ_L = y, xQ_R = None,xc = None, sense = GRB.MINIMIZE)
        modely.update()
        modely.optimize()
        modely.printAttr('x')
        soly = modely.getAttr('x')
        # append new Set_L entries
        # -------------------------
# Append new Set_L entries after updating x and y
# -------------------------
        for idx in range(G.shape[0]):
            LHS_new = G[idx]
            RHS_new = float(h[idx])
    # Only add if this hyperplane is not already present for this polyhedron
            exists = any(np.allclose(item.LHS, LHS_new) and item.poly == basis_counter for item in Set_L)
            if not exists:
        # Determine if this hyperplane is nontrivial
                ind_flag = 1 if not np.allclose(LHS_new, 0.0) else 0
        # Append new Set_L entry
                Set_L.append(Set_L_Struct(ind=ind_flag, poly=basis_counter, LHS=LHS_new, RHS=RHS_new))

        ztilde = np.dot(objy,soly) + np.dot(c,solx)
        if (ztilde < zbar):
            for ii in range(len(solx)):
                xbar[ii] = solx[ii]
            for ii in range(len(soly)):
                ybar[ii] = soly[ii]
            zbar = ztilde
        basis_counter += 1
    elif status == GRB.OPTIMAL and modeldummy.objVal <= -1e-6:
        count_rel_interior_empty += 1
        continue
    else:
        continue