# -*- coding: utf-8 -*-
"""
Created on Thu Dec 18 07:24:44 2025

@author: clim2
"""

import numpy as np
import gurobipy as gp
from gurobipy import GRB
import time
import re
import os
import pandas as pd

def read_problem_data(filename):

    with open(filename, 'r') as f:
        text = f.read()

    blocks = text.split('Variable:')
    data = {}

    for block in blocks[1:]:
        block = block.strip()
        lines = block.splitlines()

        varname = lines[0].strip()

        # Extract content inside [ ... ]
        match = re.search(r'\[(.*?)\]', block, re.S)
        if match is None:
            raise ValueError(f"No numeric data found for variable {varname}")

        raw = match.group(1).strip()

        # Split into rows (MATLAB uses ;)
        rows = [r.strip() for r in raw.split(';') if r.strip()]

        matrix = []
        for row in rows:
            numbers = row.split()           # split by whitespace
            matrix.append([float(x) for x in numbers])

        data[varname] = np.array(matrix)

    return data

def build_Q_bar(Ax, Ay):
    m = Ax.shape[0]

    Qbar = np.zeros((m+3, m+3))

    # Top-left block
    Qbar[:m, :m] = Ax + Ay

    # Bottom-right 3x3 block
    Qbar[m:, m:] = np.array([
        [0,  0,  -1],
        [0,  0,  1],
        [-1, 1,  0]
    ])
    
    return -Qbar
    
def build_A_bar(A):
    m = A.shape[0]
    ones = np.ones((m, 1))

    A_bar = np.zeros((m+4, m+3))

    A_bar[:m, :m] = -A
    
    A_bar[:m, m]  = ones[:, 0]      # m+1st column
    A_bar[:m, m+1]  = -ones[:, 0]      # m+2nd column
    
    A_bar[m, :m] = 1                # m+1st row
    A_bar[m+1, :m] = -1             # m+2nd row

    A_bar[m+2, m+2] = 1             # (m+2,m+2) = 1
    A_bar[m+3, m+2] = -1            # (m+3, m+2) = -1

    b_bar = np.zeros(m+4)
    b_bar[m]   = 1
    b_bar[m+1] = -1
    b_bar[m+2] = 1
    b_bar[m+3] = -1

    return A_bar, b_bar

def M_value(A_y, b_y, Q, x_opt, Lower_bound, Best_solution, time_limit, tolerr):
    """
    Compute Big-M constant for R4B MILP reformulation using Gurobi.
    
    A_y: (m_y, n_y) numpy array
    b_y: (m_y, 1) numpy array
    Q:   (n_x, n_y) numpy array
    x_opt: (n_x,) numpy array
    Lower_bound, Best_solution: scalars
    time_limit: float, solver time limit
    tolerr: float, MIPGap tolerance
    """
    m_y, n_y = A_y.shape

    model = gp.Model("M_value")
    model.setParam("OutputFlag", 0)
    model.setParam("TimeLimit", time_limit)
    model.setParam("MIPGap", tolerr)

    # Variables
    M = model.addVar(lb=0.0, name="M")                   # scalar Big-M
    y = model.addMVar(n_y, lb=0.0, name="y")            # continuous variables
    z = model.addMVar(m_y, lb=0.0, name="z")            # continuous dual variables

    # Base feasibility constraints
    model.addConstr(A_y @ y >= b_y.flatten(), name="primal_feas")
    model.addConstr(A_y.T @ z <= Q.T @ x_opt, name="dual_feas")
    model.addConstr(z >= 0, name="dual_nonneg")
    
    # Bounds on dual objective
    if np.isfinite(Lower_bound):
        model.addConstr(b_y.flatten() @ z >= Lower_bound, name="dual_lb")
    if np.isfinite(Best_solution):
        model.addConstr(b_y.flatten() @ z <= Best_solution, name="dual_ub")

    # Big-M bounding constraints (elementwise)
    for i in range(m_y):
        model.addConstr(A_y[i, :] @ y - b_y[i, 0] <= M, name=f"M_primal_{i}")
        model.addConstr(z[i] <= M, name=f"M_z_{i}")
    for j in range(n_y):
        model.addConstr(y[j] <= M, name=f"M_y_{j}")
        model.addConstr(Q[:, j].T @ x_opt - A_y[:, j].T @ z <= M, name=f"M_dual_{j}")

    # Objective: minimize M
    model.setObjective(M, GRB.MINIMIZE)

    # Solve
    start = time.time()
    model.optimize()
    solve_time = time.time() - start

    if model.Status in [GRB.INFEASIBLE, GRB.UNBOUNDED, GRB.INF_OR_UNBD]:
        # fallback if problem infeasible
        return 1_000_000.0, solve_time

    return M.X #, solve_time
   
def R4B_linear(Q, A_x, b_x, A_y, b_y, tolerr, time_limit):
    n_x = A_x.shape[1]
    n_y = A_y.shape[1]
    m_x = A_x.shape[0]
    m_y = A_y.shape[0]
    
    val = -np.inf
    obj = np.inf
    
    x_opt = None
    y_opt = None
    
   
    model = gp.Model("McCormick")
    model.setParam("OutputFlag", 0)
    model.setParam("TimeLimit", time_limit)
    
    x = model.addMVar(n_x, lb=0.0, name="x")
    y = model.addMVar(n_y, lb=0.0, name="y")
    gamma = model.addMVar((n_x, n_y), lb=0.0, name="gamma")
    
    model.addConstr(A_x @ x >= b_x.flatten())    
    constr_z0 = model.addConstr(A_y @ y >= b_y.flatten(), name = "z0")
    
    mc1 = {}   
    mc2 = {}
    # McCormick constraints
    for k in range(m_y):
        mc1[k] = model.addConstr(A_y[k, :] @ gamma.T - b_y[k] * x >= 0, name=f"mc1_{k}")
        
        for r in range(m_x):
            mc2[k, r] = model.addConstr(
                (A_y[k, :] @ gamma.T) @ A_x[r, :].T
                + b_y[k] * b_x[r]
                - (A_y[k, :] @ y) * b_x[r]
                - b_y[k] * (A_x[r,:] @ x)
                >= 0, name=f"mc2_{k}_{r}"
            )   
 
    for k in range(m_x):
        model.addConstr(A_x[k, :] @ gamma - b_x[k] * y >= 0)
         
    model.setObjective(gp.quicksum(Q[i, j] * gamma[i, j]
                                       for i in range(n_x)
                                       for j in range(n_y)),
                           GRB.MINIMIZE)
    
    model.optimize()
#    model.write("mccormick1.lp")
    
    if model.status != GRB.OPTIMAL:
        return -np.inf, time.time() - start_time, None, None, None

    gamma_val = gamma.X
    val = np.sum(Q * gamma_val)
    x_opt = x.X
#    y_Mc=y_opt                            # this is None, which doesn't make sense, but Zhen et al.'s matlab code is written this way.
    y_opt = y.X 
    y_Mc=y_opt                            # moved the location of this line so that y_Mc has the value of y_opt, not None.
    obj = x_opt @ Q @ y_opt
    
    if model.status == GRB.OPTIMAL:
        lin_val = -np.inf
        val = -np.inf
    else:
        lin_val = val
        #return -np.inf, time.time() - start_time, None, None, None
 
    z0 = constr_z0.Pi
    z1 = np.zeros((m_y, n_x))
#    mc_constr = {}
    for k in range(m_y):
        z1[k, :] = mc1[k].Pi

    x_GBD = x_opt
    y_GBD = y_opt
    z_opt = z0
    GBD_val = -np.inf

    # Mountain Climbing
    while GBD_val < obj and time.time() - start_time < time_limit:

     # Fix x, optimize y
         model_y = gp.Model("GBD_y")
         model_y.setParam("OutputFlag", 0)
         y_var = model_y.addMVar(n_y, lb=0.0)
         
         constr_z0 = model_y.addConstr(A_y @ y_var >= b_y.flatten(), name="Ay_ge_b")
         model_y.setObjective(x_GBD @ Q @ y_var, GRB.MINIMIZE)
         model_y.optimize()
         
         y_GBD = y_var.X
    
         obj_new = x_GBD @ Q @ y_GBD
    
         if obj_new <= obj:
             x_opt = x_GBD
             y_opt = y_GBD
             z_opt = constr_z0.Pi
             obj = obj_new
             Best_solution = obj
             Lower_bound = val
         if abs(obj-val) > tolerr:
             model_y = gp.Model("GBD_y")
             model_y.setParam("OutputFlag", 0)
             y_var = model_y.addMVar(n_y, lb=0.0)
             constr_z0 = model_y.addConstr(A_y @ y_var >= b_y.flatten(), name="Ay_ge_b")
             model_y.setObjective(x_GBD @ Q @ y_var, GRB.MINIMIZE)
             model_y.optimize()
             y_GBD = y_var.X
             GBD_val = x_GBD @ Q @ y_GBD
         else: 
             break
             
    Best_solution=obj
    Lower_bound=val
    
    if model_y.status != 1:
        val = lin_val
        ind_y = np.where(y_Mc != 0)[0]
        
        if ind_y.size != 0:
            gamma_s = gamma_val[:, ind_y] / y_Mc[ind_y].reshape(1, -1)
            size_x = ind_y.size
            
            for i in range(size_x):
                x = gamma_s[:,i]
                
                if abs(obj-val) > tolerr and np.sum(A_x @ x - b_x.flatten() > -1e-5) == b_x.size:
                    model_y = gp.Model("GBD_y_inner")
                    model_y.setParam("OutputFlag", 0)
                    model_y.setParam("TimeLimit", max(time_limit - (time.time() - start_time), 0))
                    
                    y_var = model_y.addMVar(n_y, lb=0.0, name="y")
                    model_y.addConstr(A_y @ y_var >= b_y.flatten())
                    model_y.addConstr(y_var >= 0)
                    model_y.setObjective(x @ Q @ y_var, GRB.MINIMIZE)
            
                    model_y.optimize()
                    
                    y_val = y_var.X
                    obj_new = x @ Q @ y_val
                    
                    if obj_new < obj:
                        y_opt = y_val.copy()
                        x_opt = x.copy()
                        obj = obj_new
                        
                        y_GBD = y_val.copy()
                        GBD_val = -np.inf
                                
            
                        while GBD_val < obj and (time.time() - start_time) < time_limit:
            
                            # Solve x-subproblem
                            model_x = gp.Model("GBD_x_inner")
                            model_x.setParam("OutputFlag", 0)
                            model_x.setParam("TimeLimit", max(time_limit - (time.time() - start_time), 0))
            
                            x_var = model_x.addMVar(n_x, lb=0.0, name="x")
                            model_x.addConstr(A_x @ x_var >= b_x.flatten())
                            model_x.addConstr(x_var >= 0)
                            model_x.setObjective(x_var @ Q @ y_GBD, GRB.MINIMIZE)
            
                            model_x.optimize()
            
                            x_GBD = x_var.X
                            obj_new = x_GBD @ Q @ y_GBD
            
                            if obj_new < obj:
                                x_opt = x_GBD
                                y_opt = y_GBD
                                obj = obj_new
                                Best_solution = obj
                                Lower_bound = val
                                print(f"Time={time.time()-start_time:.4f}  lower bound={Lower_bound:.4f}  best value={Best_solution:.4f}")
            
                            # Solve y-subproblem 
                            if abs(obj - val) > tolerr:
                                model_y = gp.Model("GBD_y_inner2")
                                model_y.setParam("OutputFlag", 0)
                                model_y.setParam("TimeLimit", max(time_limit - (time.time() - start_time), 0))
            
                                y_var = model_y.addMVar(n_y, lb=0.0, name="y")
                                model_y.addConstr(A_y @ y_var >= b_y.flatten())
                                model_y.addConstr(y_var >= 0)
                                model_y.setObjective(x_GBD @ Q @ y_var, GRB.MINIMIZE)
            
                                model_y.optimize()
            
                                y_GBD = y_var.X
                                GBD_val = x_GBD @ Q @ y_GBD
            
                            else:
                                break        

                        Best_solution = obj
                        Lower_bound = val
                        print(f"Time={time.time()-start_time:.4f}  lower bound={Lower_bound:.4f}  best value={Best_solution:.4f}")        
        
    if abs(val - obj) <= tolerr:
        Best_solution = obj
        Lower_bound = val
        print(f"Time={time.time()-start_time:.4f}  lower bound={Lower_bound:.4f}  best value={Best_solution:.4f}")
        print("\nThe problem is solved to OPTIMALITY using LDR.\n")
        
        sol_x = x_opt
        sol_y = y_opt
    else:
        sol_x = x_opt
        sol_y = y_opt
        
        print("\nThe problem is APPROXIMATED using LDR.\n")
        print("R4B is using MILP reformulation now to solve the solution of the bilinear problem.\n")

        obj_opt = obj
        Best_solution = obj_opt
        Lower_bound = val

        current_time = time.time()-start_time
        print(f"Time={current_time:.4f}  lower bound={Lower_bound:.4f}  best value={Best_solution:.4f}")
        
        # Calculate Big-M
        print("The value of BigM is being calculated:")        
        
        M = M_value(A_y, b_y, Q, x_opt, Lower_bound, Best_solution,
                        time_limit - (time.time()-start_time), tolerr)

        #M = 1000 * np.max(np.abs(Q))
        
#        M = M_value(A_y, b_y, Q, x_opt, Lower_bound, obj, time_limit, tolerr)
        
        M *= 10
    
        model = gp.Model("MILP")
        model.setParam("OutputFlag", 0)
        model.setParam("TimeLimit", max(time_limit - (time.time() - start_time),0))
        model.setParam("MIPGap", tolerr)
    
        x = model.addMVar(n_x, lb=0.0, name="x")
        y = model.addMVar(n_y, lb=0.0, name="y")
        z = model.addMVar(m_y, lb=0.0, name="z")
    
        u = model.addMVar(n_y, vtype=GRB.BINARY, name="u")
        v = model.addMVar(m_y, vtype=GRB.BINARY, name="v")
        
        x.start = sol_x
        y.start = sol_y
        z.start = z_opt
        
        u_start = np.sign(np.round(Q.T @ x_opt - A_y.T @ z_opt, 3))
        u_start = np.clip(u_start, 0, 1)  # convert -1,0,1 to 0/1 for Gurobi
        v_start = np.abs(np.sign(np.round(b_y.flatten() - A_y @ y_opt, 3)))
        v_start = np.clip(v_start, 0, 1)
        
        u.start = u_start
        v.start = v_start
    
        model.addConstr(A_x @ x >= b_x.flatten() - tolerr)
        model.addConstr(A_y @ y >= b_y.flatten() - tolerr)
        model.addConstr(A_y.T @ z <= Q.T @ x + tolerr)
        model.addConstr(Q.T @ x - A_y.T @ z <= M * u + tolerr)
        model.addConstr(y <= M * (1 - u))
        model.addConstr(b_y.flatten() - A_y @ y >= -M * v)
        model.addConstr(z <= M * (1 - v))
        model.addConstr(b_y.T @ z >= Lower_bound)
    
        model.setObjective(b_y.T @ z, GRB.MINIMIZE)
        model.optimize()
        
        model.write("MILP.lp")
        
    
        if model.status == GRB.OPTIMAL:
            obj = model.ObjVal
            val = model.ObjBound
            sol_x = x.X
            sol_y = y.X
    
    total_time = time.time() - start_time
    return val, total_time, sol_x, sol_y, obj    

# main starts here: read all txt files in the current folder and run R4B_linear
results = []

current_dir = os.getcwd()
txt_files = [f for f in os.listdir(current_dir) if f.endswith(".txt")]

for fname in txt_files:
    try:
        print(f"\nProcessing {fname} ...")

        data = read_problem_data(fname)

        # Assign variables
        Ax = data["A_x"]
        Ay = data["A_y"]
        x_LH = data["x_LH"]
        y_LH = data["y_LH"]
        
        Q = build_Q_bar(Ax, Ay)
        A_x, b_x = build_A_bar(Ay.T)      # Ay.T is the correct input for A_x
        A_y, b_y = build_A_bar(Ax)      # Ax is the correct input for A_y
        
        b_x = b_x.reshape(-1, 1)
        b_y = b_y.reshape(-1, 1)

        start_time = time.time()

        val, runtime, sol_x, sol_y, obj = R4B_linear(
            Q, A_x, b_x, A_y, b_y,
            tolerr=1e-4,
            time_limit=1000
        )

        total_time = time.time() - start_time

        print(
            f"File={fname} | "
            f"val={val:.6f} | "
            f"obj={obj:.6f} | "
            f"solver_time={runtime:.2f}s | "
            f"total_time={total_time:.2f}s",
            flush=True
        )
        
        row = {
            "file": fname,
            "val": val,
            "obj": obj,
            "runtime_solver": runtime,
            "runtime_total": total_time,
        }
        
        if sol_x is not None:
            sol_x_flat = sol_x.flatten()
            for i in range(sol_x_flat.size):
                row[f"sol_x_{i+1}"] = sol_x_flat[i]
        
        # Expand sol_y
        if sol_y is not None:
            sol_y_flat = sol_y.flatten()
            for j in range(sol_y_flat.size):
                row[f"sol_y_{j+1}"] = sol_y_flat[j]

        results.append(row)
        
        # results.append({
        #     "file": fname,
        #     "val": val,
        #     "obj": obj,
        #     "runtime_solver": runtime,
        #     "runtime_total": total_time,
        #     "n_x": sol_x.size if sol_x is not None else None,
        #     "n_y": sol_y.size if sol_y is not None else None,
        #     "sol_x": sol_x.flatten().tolist(),
        #     "sol_y": sol_y.flatten().tolist()
        # })

    except Exception as e:
        print(f" Error in {fname}: {e}")
        results.append({
            "file": fname,
            "val": None,
            "obj": None,
            "runtime_solver": None,
            "runtime_total": None,
            "n_x": None,
            "n_y": None,
            "error": str(e)
        })

# Convert to DataFrame
df_results = pd.DataFrame(results)

print("\n===== SUMMARY TABLE =====")
print(df_results)

# Save to CSV
df_results.to_csv("R4B_bimatrix_results.csv", index=False)
# main ends here

