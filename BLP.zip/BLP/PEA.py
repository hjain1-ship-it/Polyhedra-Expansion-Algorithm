# -*- coding: utf-8 -*-
"""
Created on Wed Dec 24 14:19:06 2025

@author: hjain1
"""

import numpy
import time
import gurobipy as gp
from gurobipy import GRB
import openpyxl
wb = openpyxl.load_workbook("Output.xlsx")
sheet = wb.active
file_counter = 1
for outer_loop in range(1,11):
    file_name = str(file_counter) + ".txt"
    fp = open(file_name,"r")
    start_time = time.perf_counter()
    count = 1
    for line in fp:
        currentline = line.split(",")
        if (count == 1):
            m = int(currentline[0])
            count = count + 1
            continue
        if (count == 2):
            n = int(currentline[0])
            count = count + 1
            continue
        if (count == 3):
            p = int(currentline[0])
            count = count + 1
            continue
        if (count == 4):
            l = int(currentline[0])
            count = count + 1
            continue
        if (count == 5):
            c = [float(currentline[ii]) for ii in range(n)]
            count = count + 1
            continue
        if (count == 6):
            d = [float(currentline[ii]) for ii in range(p)]
            count = count + 1
            continue
        if (count == 7):
            Q = [[float(currentline[ii]) for ii in range(p)]]
            count = count + 1
            continue
        if (count > 7 and count < 7 + n):
            Q.append([float(currentline[ii]) for ii in range(p)])
            count = count + 1
            continue
        if (count == 7 + n ):
            A = [[float(currentline[ii]) for ii in range(n)]]
            count = count + 1
            continue
        if (count > 7 + n and count < 7 + n + m):
            A.append([float(currentline[ii]) for ii in range(n)])
            count = count + 1
            continue
        if (count == 7 + n + m ):
            E = [[float(currentline[ii]) for ii in range(p)]]
            count = count + 1
            continue
        if (count > 7 + n + m and count < 7 + n + m + l):
            E.append([float(currentline[ii]) for ii in range(p)])
            count = count + 1
            continue
        if (count == 7 + n + m + l ):
            b = [float(currentline[ii]) for ii in range(m)]
            count = count + 1
            continue
        if (count == 7 + n + m + l + 1 ):
            f = [float(currentline[ii]) for ii in range(l)]
            count = count + 1
            break
        
    fp.close()
    E_Delta = [[0 for ii in range(p+1)] for jj in range(l)]
    for ii in range(p+1):
        for jj in range(l):
            if (ii == p):
                E_Delta[jj][ii] = -1
            else:
                E_Delta[jj][ii] = E[jj][ii]

    # Create a new model for solving linear problem in y
    modely = gp.Model("lp_y")
    modely.setParam('OutputFlag',False)
    y = modely.addMVar(p, lb = -GRB.INFINITY, vtype = GRB.CONTINUOUS)
    modely.update()
    solx = [2 for ii in range(n)]
    objy = numpy.matmul(numpy.transpose(solx),Q) + numpy.transpose(d)
    objy = numpy.full(p, objy)
    modely.setMObjective(None, objy,0.0, xQ_L = y, xQ_R = None,xc = None, sense = GRB.MINIMIZE)
    modely.update()
    expr = modely.getObjective()
    # y constraints
    E = numpy.full((l,p),E)
    f = numpy.full(l, f)
    modely.addMConstr(E,y,GRB.GREATER_EQUAL,f)
    modely.update()
    modely.optimize()
    soly = modely.getAttr('x')

    # Create a new model for solving linear problem in x
    modelx = gp.Model("lp_x")
    modelx.setParam('OutputFlag',False) # turn off console output
    x = modelx.addMVar(n, vtype = GRB.CONTINUOUS)
    modelx.update()
    objx = numpy.matmul(numpy.transpose(soly),numpy.transpose(Q)) + c
    objx = numpy.full(n,objx)
    modelx.reset(0)
    modelx.setMObjective(None, objx,0.0, xQ_L = x, xQ_R = None,xc = None, sense = GRB.MINIMIZE)
    modelx.update()
    expr = modelx.getObjective()
    #x constraints
    A = numpy.full((m,n),A)
    b = numpy.full(m, b)
    modelx.addMConstr(A,x,GRB.EQUAL,b)
    modelx.update()
    objx = [0 for ii in range(n)]
    objy = [0 for ii in range(p)]
    modelx.optimize()
    modelx.printAttr('x')
    solx = modelx.getAttr('x')
    basishead = [0 for ii in range(m)]
    nonbasis = [0 for ii in range(n-m)]
    vbasis = modelx.getAttr('Vbasis')
    jj = 0
    kk = 0
    x_basis = [[0 for ii in range(m)]]
    for ii in range(len(vbasis)):
        if (vbasis[ii] == 0):
            basishead[jj] = ii
            x_basis[0][jj] = ii
            jj = jj + 1
        else:
            nonbasis[kk] = ii
            kk = kk + 1
    B = [[0 for ii in range(m)] for jj in range(m)]
    N = [[0 for ii in range(n-m)] for jj in range(m)]
    BinvN = [[0 for ii in range(n-m)] for jj in range(m)]
    for ii in range(m):
        for jj in range(m):
            B[ii][jj] = A[ii][basishead[jj]]
    for ii in range(m):
        for jj in range(n-m):
            N[ii][jj] = A[ii][nonbasis[jj]]
    BinvN = numpy.matmul(numpy.linalg.inv(B),N)

    objy = numpy.matmul(numpy.transpose(solx),Q) + numpy.transpose(d)
    modely.update()
    objy = numpy.full(p, objy)
    modely.setMObjective(None, objy,0.0, xQ_L = y, xQ_R = None,xc = None, sense = GRB.MINIMIZE)
    modely.update()
    expr = modely.getObjective()
    modely.optimize()
    modely.printAttr('x')
    soly = modely.getAttr('x')
    yi_hat = [0 for ii in range(p)]
    yi = [0 for ii in range(p)]
    xbar = [0 for ii in range(n)]
    for ii in range(len(solx)):
        xbar[ii] = solx[ii]
    ybar = [0 for ii in range(p)]
    for ii in range(len(soly)):
        ybar[ii] = soly[ii]
    zbar = numpy.dot(objy,soly) + numpy.dot(c,solx)

    QN = [[0 for ii in range(p)] for jj in range(n-m)]
    cN = [0 for ii in range(n-m)]
    jj = 0
    for ii in nonbasis:
        QN[jj] = Q[ii]
        cN[jj] = c[ii]
        jj = jj + 1

    QB = [[0 for ii in range(p)] for jj in range(m)]
    cB = [0 for ii in range(m)]
    jj = 0
    for ii in basishead:
        QB[jj] = Q[ii]
        cB[jj] = c[ii]
        jj = jj + 1

    G = QN - numpy.matmul(numpy.transpose(BinvN),QB)
    h = numpy.matmul(numpy.transpose(BinvN),cB) - cN
    basis_counter = 0
    class Set_L_Struct():
        ind: int
        poly: int
        LHS: list
        RHS: float
    Set_L = [Set_L_Struct() for i in range((n-m)*basis_counter,(n-m)*(basis_counter + 1))]
    for ii in range (n-m):
        Set_L[ii].ind = 1
        Set_L[ii].poly = basis_counter
        Set_L[ii].RHS = h[ii]
        Set_L[ii].LHS = G[ii]
        count2 = 0
        for jj in range (p):
            if(Set_L[ii].LHS[jj] == 0.0):
                count2 = count2 + 1
        if (count2 == p):
            Set_L[ii].ind = 0

    s = 10**(-6) #epsilon
    basis_counter = basis_counter + 1
    i = 0 # iteration index
    count_rel_interior_empty = 0 # to count the number of hyperplanes that end up with no relative interior

    def Step_1():
        count1 = 0
        for ii in range(len(Set_L)):
            if (Set_L[ii].ind != 0):
                return 0 # Set L is not empty
            else:
                count1 = count1 + 1
                if (count1 == len(Set_L)):
                    return 1

    # Create a new model for solving linear problem in x
    modeldummy = gp.Model("lp_dummy")
    modeldummy.setParam('OutputFlag',False)
    ydummy = [ii for ii in range(p)]
    modeldummy.addVars(ydummy,lb = -GRB.INFINITY, vtype = GRB.CONTINUOUS)
    # add delta as a variable - Delta
    modeldummy.addVar(name = "Delta")
    modeldummy.update()
    modeldummy.setObjective(modeldummy.getVarByName("Delta"), GRB.MAXIMIZE)
    modeldummy.update()
    # y constraints for dummy model
    E_Delta = numpy.full((l,p+1),E_Delta)
    modeldummy.addMConstr(E_Delta,None,GRB.GREATER_EQUAL,f)
    modeldummy.update()
    Skq_delta_hat = [[0 for ii in range(p+1)] for jj in range(n-m-1)]

    def Step_4():
        count2 = 0
        for kk in range (0, len(E)):
            if (numpy.dot(E[kk],yi) >= f[kk]):
                count2 = count2 + 1
        if (count2 == len(E)):
            for ii in range(0,len(Set_L),n-m):
                count1 = 0
                if (round(numpy.dot(Set_L[ii].LHS,yi) - Set_L[ii].RHS,15) >= 0 ):
                    count1 = count1 + 1
                    for jj in range (ii + 1, ii + n - m):
                        if (round(numpy.dot(Set_L[jj].LHS,yi) - Set_L[jj].RHS,15) >= 0 ):
                            count1 = count1 + 1
                        else:
                            break
                if (count1 == n-m):
                    return 1 # yi belongs to S_hat
                else:
                    continue
            return 0
        else:
            return 0    

    while(i>=0):
        L_empty = Step_1()
        if (L_empty == 1):
            file_counter = file_counter + 1
            sheet.cell(row = outer_loop, column = 1).value = (time.perf_counter() - start_time)
            sheet.cell(row = outer_loop, column = 2).value = zbar
            sheet.cell(row = outer_loop, column = 3).value = len(Set_L)/(n-m)
            sheet.cell(row = outer_loop, column = 4).value = count_rel_interior_empty
            wb.save('Output.xlsx')
            break
        elif (L_empty == 0):
            i = i + 1
            q = i - 1 # sequential selection
            alpha = Set_L[q].LHS
            beta = Set_L[q].RHS
            k = Set_L[q].poly
            Set_L[q].ind = 0
            kk = 0
            Skq_delta_RHS = []
            for ii in range(k*(n-m),(k+1)*(n-m)):
                if(ii != q):
                    Skq_delta_RHS.append(Set_L[ii].RHS)
                    for jj in range(p+1):
                        if (jj == p):
                            Skq_delta_hat[kk][jj] = -1
                        else:
                            Skq_delta_hat[kk][jj] = Set_L[ii].LHS[jj]
                    kk = kk + 1
            Skq_delta_RHS = numpy.full(n-m-1, Skq_delta_RHS)
            Skq_delta_hat = numpy.full((n-m-1,p+1), Skq_delta_hat)
            modeldummy.reset(0)
            modeldummy.addMConstr(Skq_delta_hat,None,GRB.GREATER_EQUAL,Skq_delta_RHS,"Skq")
            modeldummy.update()
            exp = gp.LinExpr()
            for kk in range (p):
                exp.addTerms(alpha[kk],modeldummy.getVarByName(str("C"+ str(kk))))
            modeldummy.addConstr(exp,GRB.EQUAL ,beta,'alpha')
            modeldummy.update()
            modeldummy.optimize()
            modeldummy.remove(modeldummy.getConstrByName('alpha'))
            for ii in range(0,n-m-1):
                modeldummy.remove(modeldummy.getConstrByName('Skq['+str(ii)+']'))
            if (modeldummy.getAttr('Status')== 2 and modeldummy.getAttr('objval') > -(10**(-8))):
                yi_hat = modeldummy.getAttr('x')
                magni = s/numpy.linalg.norm(alpha)
                for ii in range(p):
                    yi[ii] = yi_hat[ii] - (magni*alpha[ii])
                yi_in_polyhedron = Step_4()
                if (yi_in_polyhedron == 1):
                    continue
                elif (yi_in_polyhedron == 0):
                    # Step 5
                    objx = numpy.matmul(numpy.transpose(yi),numpy.transpose(Q)) + c
                    objx = numpy.full(n,objx)
                    modelx.reset(0)
                    modelx.setMObjective(None, objx,0.0, xQ_L = x, xQ_R = None,xc = None, sense = GRB.MINIMIZE)
                    modelx.optimize()
                    modelx.printAttr('x')
                    solx = modelx.getAttr('x')
                    vbasis = modelx.getAttr('Vbasis')
                    jj = 0
                    kk = 0
                    for ii in range(len(vbasis)):
                        if (vbasis[ii] == 0):
                            basishead[jj] = ii
                            jj = jj + 1
                        else:
                            nonbasis[kk] = ii
                            kk = kk + 1
                    for ii in range(m):
                        for jj in range(m):
                            B[ii][jj] = A[ii][basishead[jj]]
                    for ii in range(m):
                        for jj in range(n-m):
                            N[ii][jj] = A[ii][nonbasis[jj]]
                    BinvN = numpy.matmul(numpy.linalg.inv(B),N)
                    repeat = 0
                    for kk in range (len(x_basis)):
                        if (numpy.array_equal(x_basis[kk],basishead)):
                            Set_L[q].ind = 0
                            repeat = 1
                            break
                    if (repeat == 0):
                        x_basis.append([0 for ii in range(m)])
                        for ii in range (m):
                            x_basis[basis_counter][ii] = basishead[ii]
                    else:
                        continue
                    objy = numpy.matmul(numpy.transpose(solx),Q) + numpy.transpose(d)
                    modely.reset(0)
                    modely.setMObjective(None, objy,0.0, xQ_L = y, xQ_R = None,xc = None, sense = GRB.MINIMIZE)
                    modely.update()
                    modely.optimize()
                    modely.printAttr('x')
                    soly = modely.getAttr('x')
                    jj = 0
                    for ii in nonbasis:
                        QN[jj] = Q[ii]
                        cN[jj] = c[ii]
                        jj = jj + 1
                    jj = 0
                    for ii in basishead:
                        QB[jj] = Q[ii]
                        cB[jj] = c[ii]
                        jj = jj + 1
                    G = QN - numpy.matmul(numpy.transpose(BinvN),QB)
                    h = numpy.matmul(numpy.transpose(BinvN),cB) - cN
                    for ii in range ((n-m)*basis_counter,(n-m)*(basis_counter + 1)):
                        Set_L.append(Set_L_Struct())
                        Set_L[ii].ind = 1
                        Set_L[ii].poly = basis_counter
                        Set_L[ii].RHS = h[ii - (n-m)*basis_counter]
                        Set_L[ii].LHS = G[ii - (n-m)*basis_counter]
                        count2 = 0
                        for jj in range (p):
                            if(Set_L[ii].LHS[jj] == 0.0):
                                count2 = count2 + 1
                        if (count2 == p):
                            Set_L[ii].ind = 0
                    ztilde = numpy.dot(objy,soly) + numpy.dot(c,solx)
                    if (ztilde < zbar):
                        for ii in range(len(solx)):
                            xbar[ii] = solx[ii]
                        for ii in range(len(soly)):
                            ybar[ii] = soly[ii]
                        zbar = ztilde
                    basis_counter = basis_counter + 1
            elif(modeldummy.getAttr('Status')== 2 and modeldummy.getAttr('objval') <= -(10**(-8))):
                count_rel_interior_empty = count_rel_interior_empty + 1
                continue
            elif(modeldummy.getAttr('Status') != 2):
                continue