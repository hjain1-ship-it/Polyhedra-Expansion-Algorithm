import gurobipy as gp
from gurobipy import GRB
import numpy
import time
import openpyxl

wb = openpyxl.load_workbook("Output.xlsx")
sheet = wb.active
file_counter = 1
for outer_loop in range(1,11):
    file_name = str(file_counter) + ".txt"
    fp = open(file_name,"r")
    start_time = time.perf_counter()
    count = 1
    for line in fp:
        currentline = line.split(",")
        if (count == 1):
            m = int(currentline[0])
            count = count + 1
            continue
        if (count == 2):
            n = int(currentline[0])
            count = count + 1
            continue
        if (count == 3):
            p = int(currentline[0])
            count = count + 1
            continue
        if (count == 4):
            l = int(currentline[0])
            count = count + 1
            continue
        if (count == 5):
            c = [float(currentline[ii]) for ii in range(n)]
            count = count + 1
            continue
        if (count == 6):
            d = [float(currentline[ii]) for ii in range(p)]
            count = count + 1
            continue
        if (count == 7):
            Q = [[float(currentline[ii]) for ii in range(p)]]
            count = count + 1
            continue
        if (count > 7 and count < 7 + n):
            Q.append([float(currentline[ii]) for ii in range(p)])
            count = count + 1
            continue
        if (count == 7 + n ):
            A = [[float(currentline[ii]) for ii in range(n)]]
            count = count + 1
            continue
        if (count > 7 + n and count < 7 + n + m):
            A.append([float(currentline[ii]) for ii in range(n)])
            count = count + 1
            continue
        if (count == 7 + n + m ):
            E = [[float(currentline[ii]) for ii in range(p)]]
            count = count + 1
            continue
        if (count > 7 + n + m and count < 7 + n + m + l):
            E.append([float(currentline[ii]) for ii in range(p)])
            count = count + 1
            continue
        if (count == 7 + n + m + l ):
            b = [float(currentline[ii]) for ii in range(m)]
            count = count + 1
            continue
        if (count == 7 + n + m + l + 1 ):
            f = [float(currentline[ii]) for ii in range(l)]
            count = count + 1
            continue
            #break
        if (count == 7 + n + m + l + 2):
            lb_y = [float(currentline[ii]) for ii in range(p)]
            #count = count + 1
            break

    fp.close()
    combined = [0 for ii in range(n+p)]
    for i in range(n):
        combined[i] = c[i]
    for i in range(n, n+p):
        combined[i] = d[i-n]
    for i in range (n):
        Q[i] = numpy.full(p,Q[i])
    Q = numpy.full((n,p),Q)
    combined = numpy.full(n+p, combined)
    # Create a new model
    model = gp.Model("bilinear")
    x = model.addMVar(n, vtype = GRB.CONTINUOUS)
    model.update()
    y = model.addMVar(p, lb = lb_y, vtype = GRB.CONTINUOUS)
    model.update()
    model.setMObjective(Q, combined,0.0, xQ_L = x, xQ_R = y,xc = None, sense = GRB.MINIMIZE)
    model.update()
    expr = model.getObjective()

    # x constraints
    A = numpy.full((m,n),A)
    b = numpy.full(m, b)
    model.addMConstr(A,x,GRB.EQUAL,b)
    model.update()

    # y constraints
    E = numpy.full((l,p),E)
    f = numpy.full(l, f)
    model.addMConstr(E,y,GRB.GREATER_EQUAL ,f)
    model.update()
    model.setParam("NonConvex", 2)
    model.update()
    model.optimize()
    sheet.cell(row = outer_loop, column = 1).value = (time.perf_counter() - start_time)
    if (model.getAttr('Status')== 2):
        sheet.cell(row = outer_loop, column = 2).value = model.getAttr('ObjVal')
        wb.save('Output.xlsx')
    elif(model.getAttr('Runtime')>7000):
        sheet.cell(row = outer_loop, column = 2).value = ('>7000')
        wb.save('Output.xlsx')
    else:
        sheet.cell(row = outer_loop, column = 2).value = ('Infeasible Model')
        wb.save('Output_GRB.xlsx')
    file_counter = file_counter + 1
